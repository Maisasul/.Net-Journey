﻿namespace mvc.Data
{
    public class ApplicationDbContext
    {
    }
}
