﻿namespace BookWebApplication.Models
{
    public class BookList
    {
        public int ID { get; set; }
        public string Name { get; set; }
    }
}
