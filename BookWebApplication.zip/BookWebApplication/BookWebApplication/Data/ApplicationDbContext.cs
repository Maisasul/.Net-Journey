﻿using BookWebApplication.Models;
using Microsoft.EntityFrameworkCore;

namespace BookWebApplication.Data
{
	public class ApplicationDbContext : DbContext
	{
		public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) 
		{

		}
		public DbSet<BookList> booksList {  get; set; }
	}
	
}
