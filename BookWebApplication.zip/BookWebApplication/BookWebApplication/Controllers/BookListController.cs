﻿using BookWebApplication.Data;
using BookWebApplication.Models;
using Microsoft.AspNetCore.Mvc;

namespace BookWebApplication.Controllers
{
    public class BookListController : Controller
    {
        private readonly ApplicationDbContext _db;
        public BookListController(ApplicationDbContext db)
        {
            _db = db;
        }
        public IActionResult Index()
        {
            List<BookList> bookobj = _db.booksList.ToList();
            return View();
        }
        public IActionResult Create()
        {
            return View();
        }
        public IActionResult Create(BookList obj)
        {
            _db.booksList.Add(obj);
            _db.SaveChanges();
            return RedirectToAction("Index");
        }

        public IActionResult Update(int id) 
        {
            var bookobj = _db.booksList.FirstOrDefault(b => b.ID == id);
            return View(bookobj);
        }
        public IActionResult Update(BookList obj)
        {
            _db.booksList.Update(obj);
            _db.SaveChanges();
            return RedirectToAction("Index");
        }
        public IActionResult Delete(int id) 
        {
            var bookobj = _db.booksList.FirstOrDefault(b => b.ID == id);
            _db.booksList.Remove(bookobj);
            _db.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
